# BachelorThesis
Temp repository for bachelor thesis.
